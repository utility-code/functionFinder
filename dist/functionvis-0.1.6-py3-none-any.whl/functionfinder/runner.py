from .main import *

fire.Fire(mainrunner)
