import fire
from .main import *

if __name__=='__main__':
    fire.Fire(mainrunner)








